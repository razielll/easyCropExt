
# Easy Crop - Awesome tool for cropping and taking screenshots
##  Version 1.0.1
Animation frame for dimensions box!
###  Version 1.0.0
Added full page screenshot shortcut

#### Version 0.0.2
Complete Revamp of code improved readability & quality
Improved performance -> requestAnimationFrame method
Reduced DOM usage
Removed redundant css
